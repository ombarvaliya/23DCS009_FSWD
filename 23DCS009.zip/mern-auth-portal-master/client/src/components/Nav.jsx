import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';

export default function Nav() {
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    // try to fetch /api/auth/me
    fetch(import.meta.env.VITE_API_BASE + '/auth/me', {
      credentials: 'include'
    })
      .then(res => res.ok ? res.json() : null)
      .then(data => {
        if (data?.user) setUser(data.user);
      }).catch(() => {});
  }, []);

  async function logout() {
    await fetch(import.meta.env.VITE_API_BASE + '/auth/logout', {
      method: 'POST',
      credentials: 'include'
    });
    setUser(null);
    navigate('/');
  }

  return (
    <nav className="bg-white shadow-sm sticky top-0 z-20">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white font-bold">A</div>
          <Link to="/" className="text-xl font-semibold text-slate-700">AuthPortal</Link>
        </div>

        <div className="flex items-center gap-4">
          {user ? (
            <>
              <span className="text-sm text-slate-600 hidden sm:inline">Hello, <strong>{user.name}</strong></span>
              <Link to="/dashboard" className="py-2 px-4 rounded-md bg-primary text-white text-sm">Dashboard</Link>
              <button onClick={logout} className="py-2 px-4 rounded-md border border-slate-200 text-sm">Logout</button>
            </>
          ) : (
            <>
              <Link to="/login" className="py-2 px-4 rounded-md text-sm">Login</Link>
              <Link to="/register" className="py-2 px-4 rounded-md bg-primary text-white text-sm">Register</Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
}
